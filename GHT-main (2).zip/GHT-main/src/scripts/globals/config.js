const CONFIG = {
  DEFAULT_LANGUAGE: 'en-us',
  CACHE_NAME: 'GHTour-V1',
};

export default CONFIG;
